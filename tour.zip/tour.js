const express = require('express')
const path = require('path')
const bodyParser = require('body-parser')
const { success, error } = require("consola");
var cors = require('cors')

const app = express()


app.use(express.static('tour'))
app.use(bodyParser.urlencoded({ extended: false }))
// parse application/json
app.use(bodyParser.json())
app.use(cors())


app.get('/', (req, res) => {
  res.sendFile(path.join(__dirname, 'index.html'));
})

app.get('/home', (req, res) => {
    res.sendFile(path.join(__dirname, 'index.html'));
  })




const startApp = async () => {
  try {
    // Start Listenting for the server on PORT
    app.listen(4040, () =>
      success({ message: `Server started on PORT 80`, badge: true })
    );
  } catch (err) {
    error({
      message: `Unable to connect with Database \n${err}`,
      badge: true
    });
    startApp();
  }
};


startApp()